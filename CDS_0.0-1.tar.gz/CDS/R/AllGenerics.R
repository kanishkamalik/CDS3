if(!isGeneric("summary"))
    setGeneric("summary", function(object,
                                   ...) standardGeneric("summary"))

## if(!isGeneric("calcSpreadDV01"))
##     setGeneric("calcSpreadDV01", function(object) standardGeneric("calcSpreadDV01"))


## if(!isGeneric("calcIRDV01"))
##     setGeneric("calcIRDV01", function(object) standardGeneric("calcIRDV01"))


## if(!isGeneric("calcRecRisk01"))
##     setGeneric("calcRecRisk01", function(object) standardGeneric("calcRecRisk01"))

## if(!isGeneric("update"))
##     setGeneric("update", function(object,
##                                   ...) standardGeneric("update"))
